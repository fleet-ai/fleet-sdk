# Auto-generated verifier module

def helper_function(x, y):
    """Helper function that will be bundled."""
    return x + y

def simple_verifier(env, threshold=10):
    """Simple verifier without decorator.
    
    This demonstrates that we can bundle and run functions
    without the @verifier decorator.
    """
    # Import helper functions inside the function
    # This ensures the import is captured by inspect.getsource()
    from zuba import helper_function_four
    
    def helper_function(x, y):
        """Helper function that will be bundled."""
        return x + y
    
    result = helper_function(5, 7)
    result2 = helper_function_four(5, 7)
    return 1.0 if result > threshold else 0.0

