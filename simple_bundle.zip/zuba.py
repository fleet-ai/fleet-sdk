# Extracted module (static analysis)
def helper_function_four(x: int, y: int) -> int:
    """Helper function that will be bundled."""
    return x + y
